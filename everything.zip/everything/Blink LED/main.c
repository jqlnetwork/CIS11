#include "msp.h"
#include "delay.h"
#include "set_DCO.h"

int main(void) {
    int i;
    set_DCO(3);
    WDT_A->CTL = WDT_A_CTL_PW | WDT_A_CTL_HOLD;    // Stop WDT

    // P1.0 set as GPIO
    P2->SEL0 &= ~BIT0;               // Clear bit 0 of the P1->SEL0 register
    P2->SEL1 &= ~BIT0;               // Clear bit 0 of the P1->SEL1 register

    P2->DIR |= BIT0;                 // P1.0 set as output

    while (1)                        // continuous loop
    {
       P2->OUT ^= BIT0;                // Toggle P1.0 LED
       delay_us(100,3);
    }
}
