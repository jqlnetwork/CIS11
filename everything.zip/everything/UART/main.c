#include "msp.h"
#include <stdio.h>
#include <stdlib.h>
#include "uart.h"

#define MAX_DAC 4095

int main(void)
{
    __disable_irq();                    //global disable IRQs while configuring
    UART0_init();


    NVIC_SetPriority(EUSCIA0_IRQn, 0);  //set priority to 3 in NVIC
    NVIC_EnableIRQ(EUSCIA0_IRQn);       //enable interrupt in NVIC
    __enable_irq();                     //enable global IRQs

    /* Configure port bits for SPI*/
    P3->DIR |= BIT0;                     // Will use BIT4 to activate /CE on the DAC
    P1SEL0 |= BIT6 | BIT5;          // Configure P1.6 and P1.5 for UCB0SIMO and UCB0CLK
    P1SEL1 &= ~(BIT6 | BIT5);            //

    /* SPI Setup */
    /* EUSCI_B0: Enhanced Universal Serial Communication Interface*/
    /* CTLW0: SPI Control Word*/
    EUSCI_B0->CTLW0 |= EUSCI_B_CTLW0_SWRST;         // Put eUSCI state machine in reset

    EUSCI_B0->CTLW0 = EUSCI_B_CTLW0_SWRST |     // Remain eUSCI state machine in reset
                      EUSCI_B_CTLW0_MST   |         // Set as SPI master
                      EUSCI_B_CTLW0_SYNC  |         // Set as synchronous mode
                      EUSCI_B_CTLW0_CKPL  |         // Set clock polarity high
                      EUSCI_B_CTLW0_MSB;            // MSB first

    EUSCI_B0->CTLW0 |= EUSCI_B_CTLW0_SSEL__SMCLK;   // SMCLK
    EUSCI_B0->BRW = 0x02;               // Baud Rate: divide by 2, clock = fBRCLK/(UCBRx)
   /*Initialize USCI state machine, SPI now waiting for something to be placed in TXBUF*/
    EUSCI_B0->CTLW0 &= ~EUSCI_B_CTLW0_SWRST;

    EUSCI_B0->IFG |= EUSCI_B_IFG_TXIFG;             // Clear TXIFG flag

    /* initialize P2.2-P2.0 for tri-color LEDs */
    P2->SEL1 &= ~7;         // configure P2.2-P2.0 as simple I/O
    P2->SEL0 &= ~7;
    P2->DIR |= 7;           // P2.2-2.0 set as output
    P2->OUT = 1;

    P2->OUT = EUSCI_A0->RXBUF;

    delayMs(1000);
    P2->OUT = 2;

    while(1)
    {
        if(txReady())
        {
            Drive_DAC(getDAC_val());
            while(!(EUSCI_A0->IFG & 0x02)) { }  // wait for transmit buffer empty
            EUSCI_A0->TXBUF = '\n';     // send new line to terminal
            EUSCI_A0->TXBUF = 13;
            resetDAC();
        }
    }
}

void Drive_DAC(unsigned int level)
{
    unsigned int DAC_Word = 0;

    DAC_Word = (0x3000) | (level & 0x0FFF);
    P3->OUT &= ~BIT0;
    EUSCI_B0->TXBUF = (unsigned char) (DAC_Word >> 8);
    while (!(EUSCI_B0->IFG & EUSCI_B_IFG_TXIFG));
    EUSCI_B0->TXBUF = (unsigned char) (DAC_Word & 0x00FF);/* Transmit lower byte to DAC*/
    while (!(EUSCI_B0->IFG & EUSCI_B_IFG_TXIFG));         /* Poll the TX flag to wait for completion*/

    while(EUSCI_B0->STATW & 1) ;
    P3->OUT |= BIT0;    /* Set P3.0   (drive /CS high on DAC)*/

    return;
}



