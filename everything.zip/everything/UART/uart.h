/*
 * uart.h
 *
 *  Created on: May 9, 2018
 *      Author: garthleung
 */

#ifndef UART_H_
#define UART_H_


int txReady(void);
int getDAC_val(void);
void resetDAC(void);
void UART0_init(void);
void delayMs(int n);


#endif /* UART_H_ */
