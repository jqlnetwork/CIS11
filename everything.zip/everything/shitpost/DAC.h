#include <STDINT.H>

#ifndef DAC_H_
#define DAC_H_

void drive_DAC(uint16_t data, uint8_t cmd);
void drive_DAC_(unsigned char data_bits);
void drive_DAC_V(float volts);

#endif /* DAC_H_ */
