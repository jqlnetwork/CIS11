#ifndef LCD_H_
#define LCD_H_

#define RS BIT5
#define RW BIT6
#define E  BIT7

#define clear_display 0x01
#define return_home 0x02
#define function_set 0x28 //8bit
#define display_on 0x0F
#define entry_mode_on 0x06
#define write_A 0x41
#define set_ddram00 0x80
#define set_ddram01 0x81

//int clk = 3;

void LCD_reset(void);
void LCD_command(unsigned char CMD);
void LCD_startup(void);
void LCD_init(void);
void LCD_write_char(unsigned char data);
void Clear_LCD(void);
void Home_LCD(void);


#endif /* LCD_H_ */

