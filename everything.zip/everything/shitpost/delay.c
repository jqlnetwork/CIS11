/*
 * delay.c
 *
 *  Created on: Apr 18, 2018
 *      Author: garthleung
 */


#include "delay.h"

#define FREQ_1_5_MHz 1
#define FREQ_3_MHz 3
#define FREQ_6_MHz 6
#define FREQ_12_MHz 12
#define FREQ_24_MHz 24
#define FREQ_48_MHz 48

int delay_ms(int ms, int freq)
{
    int i;
    if(freq == 1)
        for(i=150*ms; i>0;i--);
    else
        for (i=100*freq*ms; i>0;i--);
return 0;

}

int delay_us(int us, int freq)
{
    float scale;
    int c;
    scale = .0966;
        for(c=freq*scale*us; c>0; c--);
    return 0;
}


