/*
 * delay.h
 *
 *  Created on: Apr 18, 2018
 *      Author: garthleung
 */

#ifndef DELAY_H_
#define DELAY_H_
#define FREQ_1_5_MHz 1
#define FREQ_3_MHz 3
#define FREQ_6_MHz 6
#define FREQ_12_MHz 12
#define FREQ_24_MHz 24
#define FREQ_48_MHz 48

int delay_ms(int ms, int freq);
int delay_us(int us, int freq);


#endif /* DELAY_H_ */
