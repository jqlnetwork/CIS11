/*
 * drive_DAC.c
 *
 *  Created on: May 7, 2018
 *      Author: garthleung
 */

#include "msp.h"

void drive_dac(unsigned int data){
    int cmd = 0x30;
    P2 -> OUT &= ~BIT3;   //CS is low, this is when bits are load

    while(!(EUSCI_B0 -> IFG & 2));
    EUSCI_B0 -> TXBUF = (cmd | ((0x0F00 & data) >> 8));

    while(!(EUSCI_B0 -> IFG & 2));
    EUSCI_B0 -> TXBUF = (data & 0x00FF);

    while(EUSCI_B0 -> STATW & 1 );
    P2 -> OUT |= BIT3;

    return;
}


