#include "DAC.h"
#include "msp.h"
#include <STDINT.H>

void drive_DAC(uint16_t data, uint8_t cmd){
    P2->OUT &= ~BIT3;                           // cs low

    while(!(EUSCI_B0->IFG & EUSCI_B_IFG_TXIFG));// wait until interrupt flag appears
    EUSCI_B0 -> TXBUF = (cmd | ((data)>>8));    // send upper
    EUSCI_B0 -> TXBUF = (data) & (0xFF);        // send lower

    P2->OUT |= BIT3;                            // cs high
}

void drive_DAC_V(float volts){
    float Vdd = 3.3;
    float x = volts/Vdd;
    unsigned int hex_volts = x*4096;
    unsigned int data1 = 0x300 | hex_volts;

    P2->OUT &= ~BIT3;                               // cs low

    while(!(EUSCI_B0->IFG & EUSCI_B_IFG_TXIFG));    // wait until interrupt flag appears
    EUSCI_B0 -> TXBUF = ((data1 & 0xFF00) >> 8);    // send upper

    EUSCI_B0 -> TXBUF = (data1 & 0x00FF);           // send lower

    P2->OUT |= BIT3;                     // cs high
}



