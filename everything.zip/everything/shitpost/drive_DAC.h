/*
 * drive_DAC.h
 *
 *  Created on: May 7, 2018
 *      Author: garthleung
 */

#ifndef DRIVE_DAC_H_
#define DRIVE_DAC_H_


void drive_dac(unsigned int data);


#endif /* DRIVE_DAC_H_ */
