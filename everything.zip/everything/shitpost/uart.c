/*
 * uart.c
 *
 *  Created on: May 9, 2018
 *      Author: garthleung
 */

#include "msp.h"
#include "uart.h"

#define MAX_DAC  4095

static unsigned int DAC_val = 0;
static unsigned int txFlag = 0;

int txReady(void)
{
    return txFlag;
}

int getDAC_val(void)
{
    return DAC_val;
}

void resetDAC(void)
{
    DAC_val = 0;
    txFlag = 0;
}


/*UART Rx Interrupt Handler*/
void EUSCIA0_IRQHandler(void)
{
    char c;
    c = EUSCI_A0->RXBUF;
    P2->OUT = c;            //change led color based on character

    if((c >= 48 && c <= 57))
    {
        while(!(EUSCI_A0->IFG & 0x02)) { }  // wait for transmit buffer empty
        EUSCI_A0->TXBUF = c;
        DAC_val *= 10;
        DAC_val += (c - '0');

    }
    if( c == 13)
    {
        if(DAC_val > MAX_DAC)
            DAC_val = MAX_DAC;

        txFlag = 1;
    }
}

void UART0_init(void)
{
    EUSCI_A0->CTLW0 |= 1;       //put in reset mode for config
    EUSCI_A0->MCTLW = 0;        // disable oversampling
    EUSCI_A0->CTLW0 = 0x0081;   // 1 stop bit, no parity, SMCLK, 8-bit data
    EUSCI_A0->BRW = 26;         // 3,000,000 / 115200 = 26    //was 26 now its 78 to try 9600

    P1->SEL0 |= 0x0C;           // P1.3, P1.2 for UART
    P1->SEL1 &= ~0x0C;
    EUSCI_A0->CTLW0 &= ~1;      // take UART out of reset mode

    EUSCI_A0->IE = 0x01;        // enable Rx interrupts
}

/* delay milliseconds when system clock is at 3 MHz */
void delayMs(int n)
{
    int i, j;

    for (j = 0; j < n; j++)
        for (i = 750; i > 0; i--);      // Delay */
}



