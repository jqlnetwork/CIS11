/*
 * LCD.c
 *
 *  Created on: Apr 18, 2018
 *      Author: garthleung
 */




#include "msp.h"
#include "LCD.h"
#include "delay.h"

int clk=3; //set clk freq for delay funcs

void Clear_LCD(void){
    LCD_command(clear_display);
}

void Home_LCD(void){
    LCD_command(return_home);
}

void LCD_reset(void){ //set all pins used to zero
    P4->OUT = 0x00;
    P3->OUT = 0x00;
}

  // the following is 4bit LCD command function
void LCD_command(unsigned char CMD){

    delay_us(100,clk);

    P3->OUT &= ~(RS | RW | E);

    P4->OUT = 0x00;
    P3->OUT |= E;
    delay_us(100,clk);
    P4->OUT |= (CMD & 0xF0);  //out upper bits of CMD
    delay_us(10,clk);
    P3->OUT &= ~E;
    P4->OUT = 0x00;

    delay_ms(10,clk);

    P3->OUT &=0x1F;

    P3->OUT |= E;
    delay_us(100,clk);
    P4->OUT |= ((CMD << 4) & 0xF0); //out lower bits of CMD
    delay_us(10,clk);
    P3->OUT &= ~E;
    P4->OUT = 0x00;
    delay_us(10,clk);

}

void LCD_startup(void){ //execute startup sequence
    delay_ms(40,clk);
    LCD_command(function_set);
    delay_us(37,clk);
    LCD_command(display_on);
    delay_us(37,clk);
    LCD_command(clear_display);
    delay_ms(2,clk);
    LCD_command(entry_mode_on);

}


void LCD_init(void){ //power on LCD
    P3->DIR |= RS | RW | E ;
    P4->DIR = 0xFF;
}


 //the following function writes single char to LCD
void LCD_write_char(unsigned char data){
    delay_us(100,clk);
    P3->OUT &= ~(RS | RW | E);
    P4->OUT = 0x00;
    P3->OUT |= RS; //set RS high to write to RAM

    delay_us(100,clk);
    P4->OUT |= (data & 0xF0); //send upper nibble
    P3->OUT |= E;
    delay_us(10,clk);
    P3->OUT &= ~E;
    P4->OUT = 0x00;

    delay_ms(10,clk);

    delay_us(100,clk);
    P4->OUT |= ((data << 4) & 0xF0); //send lower nibble
    P3->OUT |= E;
    delay_us(10,clk);
    P3->OUT &= ~E;
    P4->OUT = 0x00;
}
