/*
 * uart.c
 *
 *  Created on: May 9, 2018
 *      Author: garthleung
 */

#include "msp.h"
#include "uart.h"
#include <stdio.h>
#include "string.h"
void sendchar(char word){
    while(!(EUSCI_A0 -> IFG & 0x02));
    EUSCI_A0 -> TXBUF = word;
}


void UART0_init(void)
{
    EUSCI_A0->CTLW0 |= 1;       //put in reset mode for config
    EUSCI_A0->MCTLW = 0;        // disable oversampling
    EUSCI_A0->CTLW0 = 0x0081;   // 1 stop bit, no parity, SMCLK, 8-bit data
    EUSCI_A0->BRW = 26;         // 3,000,000 / 115200 = 26    //was 26 now its 78 to try 9600

    P1->SEL0 |= 0x0C;           // P1.3, P1.2 for UART
    P1->SEL1 &= ~0x0C;
    EUSCI_A0->CTLW0 &= ~1;      // take UART out of reset mode
}

void sendline(char line[]){
    int i = 0;
    for (i = 0 ; i < strlen(line) ; i++){
        sendchar(line[i]);
    }
}
void sendnewline(){
    sendchar('\n');
    sendchar(13);
}

