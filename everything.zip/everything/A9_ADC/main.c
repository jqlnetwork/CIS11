#include "msp.h"
#include "uart.h"
#include <stdio.h>
#include "delay.h"

/**
 * main.c
 */
static unsigned int flag = 0;
static unsigned int ADCval = 0;
//float avg = [1.00,2.00,3.10];
void main(void)
{
    //init UART and ADC first
	UART0_init();
	adc_init();
	//avg[] = 0;
	ADC14 -> CTL0 |= ADC14_CTL0_SC; //Start Conversion Process

	while(1){
	    if (flag == 1){              //After conversion, flag == 1
	        sendADCresult();      //Send the converted value to UART
	        flag = 0;               //Set flag = 0, to start conversion again
	        ADC14 -> CTL0 |= ADC14_CTL0_SC;  //Start Conversion Process

	    }
	}
}

void ADC14_IRQHandler(void){
    ADCval = ADC14 -> MEM[5];    //assign ADCval to memreg5's value, the digital value.
    flag = 1;
}

void adc_init(void){
    ADC14 -> CTL0 = ADC14_CTL0_ON;
    ADC14 -> CTL0 &= ~ADC14_CTL0_ENC; //turn ADC14ENC = 0, ready to config
    ADC14 -> CTL0 |= (ADC14_CTL0_SHT0_3 | ADC14_CTL0_SHP | ADC14_CTL0_SSEL_1); //sampling, 32 cycles, single channel/single conversion, software trigger
    ADC14 -> CTL1 = ADC14_CTL1_RES_3;         // Use sampling timer, 14-bit conversion results

    ADC14 -> MCTL[5] = 15;   //memreg 5, A6 input, single-ended, Vref = AVCC
    P6 -> SEL1 |= BIT0;
    P6 -> SEL0 |= BIT0;     //configure P4.7 for A6 input
    ADC14 -> CTL1 |= 0x00050000; //configuring CTL1  reg for memreg5

    /*ADC Interrupts*/
    ADC14->IER0 |= ADC14_IER0_IE5;          // Enable ADC conv complete interrupt for MEMREG5
    NVIC->ISER[0] = 1 << ((ADC14_IRQn) & 31);   //don't know if its this or other, should i set priority?
    __enable_irq();
    ADC14 -> CTL0 |= ADC14_CTL0_ENC;    //turn it on, now its done configurating
}

void sendADCresult(){
    float value;
    char data;

    //1's place//
    value = ADCval;
    value *= (3.3/16384);
    data = (int)value + '0'; //change this to number value on ascii
    sendchar(data);
    sendchar('.');

    //0.1's place//
    value = (value - (int)value) * 10;
    data = (int)value + '0';
    sendchar(data);

    //0.01's place//
    value = (value - (int)value) * 10;
    data = (int)value + '0';
    sendchar(data);

    delay_ms(100,3);
    sendchar(' ');
    sendchar(13);
}


//void sendADCresult(){
//    float voltage = (ADCval / 4970); //* (3.3/16380));
//    voltage *= 100;
//    int x = (int) voltage;
//    int onesplace = (x/100) + '0';
//    //1's place
//    sendchar(onesplace);      //x/100
//
//    //0.1's place
//    //x %= 100;       //get the remainder of /100, so for example 330 = 30,
//    x %= 100;
//    int tenthsplace = (x/10) + '0';
//    sendchar('.');
//    sendchar(tenthsplace); // that'll give the 0.1's place //x/10
//
//    //0.01's place
//    int hundredthsplace = (x%10) + '0';
//    sendchar(hundredthsplace);  //gives 0.01's place because modulus of any 10, is just the remainder  //x%10
//    sendchar(13);
//}
















