/*
 * uart.h
 *
 *  Created on: May 9, 2018
 *      Author: garthleung
 */

#ifndef UART_H_
#define UART_H_


void UART0_init(void);
void sendchar(char word);
void sendline(char line[]);
void sendnewline();

#endif /* UART_H_ */
