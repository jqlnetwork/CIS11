/*
 * LCD.c
 *
 *  Created on: Apr 11, 2018
 *      Author: garthleung
 */
#include "delay.h"

#include "msp.h"
#include "delay.h"
#include "set_DCO.h"
#include "string.h"

//don't know if i need to do this again
#define FREQ_1_5_MHz 1
#define FREQ_3_MHz 3
#define FREQ_6_MHz 6
#define FREQ_12_MHz 12
#define FREQ_24_MHz 24
#define FREQ_48_MHz 48

#define RS BIT5
#define RW BIT6
#define EN BIT7

#define clear_disp 0x01
#define function_set 0x28 //nibble mode function set
#define display_on 0x0F     //refer to table to get display_off
#define entry_mode_on 0x06  //apparently 0x07 makes it disappear
#define setDDRAM_left 0xC0

void lcd_string(char string[])
{
    int a = 0;
    int b = strlen(string);
    for (a = 0; a < b; a++)
    {
        lcd_write(string[a]);
        delay_us(100,3);
    }
}

void lcd_clear(void){
    lcd_command(0x01);
    P4 -> OUT &= 0x00;
}

void lcd_setup(void){
    lcd_command(function_set);
    delay_us(50,3);
    lcd_command(display_on);
    delay_us(50,3);
    lcd_command(clear_disp);
    delay_ms(5,3); //LCD Startup Sequence Finished
}
void lcd_init(void){
    P3->DIR |= RS | RW | EN ;
    P4->DIR = 0xFF;
}
void lcd_write(unsigned char data){
    P3 -> OUT &= ~(RS | RW | EN);
    P3 -> OUT |= RS;
    delay_us(100,3);
    P4 -> OUT &= 0x0F;
    P4 -> OUT |= (data & 0xF0);
    delay_us(10,3); //
    P3 -> OUT |= EN;
    delay_us(10,3);
    P3 -> OUT &= ~EN;
    delay_us(100,3); //
    P4 -> OUT &= 0x0F;
    P4 -> OUT |= ((data << 4) & 0xF0);
    delay_us(10,3);
    P3 -> OUT |= EN;
    delay_us(10,3);
    P3 -> OUT &= ~EN;
    delay_ms(10,3);

}

void lcd_command(unsigned char CMD){
    delay_us(100,3);
    P3 -> OUT &= ~(RS | RW | EN);
    P4 -> OUT = 0x00;
    P3 -> OUT |= EN;
    delay_us(100,3);
    P4 -> OUT |= (CMD & 0xF0);
    delay_us(10,3); //was 10
    P3 -> OUT &= ~EN;
    P4 -> OUT = 0x00;
    delay_us(10,3);
    P3 -> OUT &= ~(RS | RW | EN);
    P3 -> OUT |= EN;
    delay_us(100,3);
    P4 -> OUT |= ((CMD << 4) & 0xF0);
    delay_us(10,3);
    P3 -> OUT &= ~EN;
    P4 -> OUT &= 0x0F;
    delay_us(10,3);
}



