/*
 * LCD.h
 *
 *  Created on: Apr 11, 2018
 *      Author: garthleung
 */

#ifndef LCD_H_
#define LCD_H_
#define FREQ_1_5_MHz 1
#define FREQ_3_MHz 3
#define FREQ_6_MHz 6
#define FREQ_12_MHz 12
#define FREQ_24_MHz 24
#define FREQ_48_MHz 48

#define RS BIT5
#define RW BIT6
#define EN BIT7

#define clear_disp 0x01
#define function_set 0x28 //nibble mode function set
#define display_on 0x0F     //refer to table to get display_off
#define entry_mode_on 0x06  //apparently 0x07 makes it disappear
#define setDDRAM_left 0xC0

void lcd_string(char string[]);
void lcd_setup(void);
void lcd_init(void);
void lcd_write(unsigned char data);
void lcd_command(unsigned char CMD);
void lcd_clear(void);

#endif /* LCD_H_ */
