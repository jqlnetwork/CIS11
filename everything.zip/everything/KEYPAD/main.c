#include "msp.h"
#include "delay.h"
#include "set_DCO.h"
#include "string.h"

/**
 * main.c
 */

#define FREQ_1_5_MHz 1
#define FREQ_3_MHz 3
#define FREQ_6_MHz 6
#define FREQ_12_MHz 12
#define FREQ_24_MHz 24
#define FREQ_48_MHz 48

#define RS BIT5
#define RW BIT6
#define EN BIT7

#define clear_disp 0x01
#define function_set 0x28 //nibble mode function set
#define display_on 0x0F     //refer to table to get display_off
#define entry_mode_on 0x06  //apparently 0x07 makes it disappear
#define setDDRAM_bottom 0xC0
#define setDDRAM_top 0x80
#define setDDRAM_middletop 0x85

#define row1 BIT1
#define row2 BIT7
#define row3 BIT6
#define row4 BIT4
#define col1 BIT2
#define col2 BIT0
#define col3 BIT5

void main(void)
{
	WDT_A->CTL = WDT_A_CTL_PW | WDT_A_CTL_HOLD;		// stop watchdog timer
	while(1){
	    //init lcd
	    lcd_init();
	    delay_ms(50,3);
	    lcd_setup();
	    lcd_command(entry_mode_on);

	    //init the keypad
	    P5 -> DIR |= (row1 | row2 | row3 | row4);
	    P5 -> DIR &= ~(col1 | col2 | col3);
	    P5 -> REN |= (col1 | col2 | col3);
	    P5 -> OUT |= (col1 | col2 | col3);  //enabled the pullup resistors for col1-3

	    //choose keypad stuff now
	    int value,row,col;
	    char button;
	    P5 -> OUT |= (row1 | row2 | row3 | row4); //rows are high
	    delay_ms(25,3);
	    value = P5 -> IN & (col1 | col2 | col3); //checks if both are low
	    lcd_write(value);

	    /*unsigned char list_of_rows[4] = {row1, row2, row3, row4};
	    for (row = 0 ; row < 4 ; row++){
	        P5 -> OUT &= list_of_rows[row]; //certain row is set low
	        delay_ms(25,3);
	        value = P5 -> IN & (col1 | col2 | col3);
	        if (value != 0){
	            break;
	        }
	    }*/

	    /*if (value == 0x14) {
	       col = 0;
	    }
	    if (value == 0x44) {
	       col = 1;
	    }
	    if (value == 0x50) {
	       col = 2;
	    }
	    if (col == 0 && row == 0) {
	        button = '1';
	    }
	    if (col == 0 && row == 1) {
	        button = '4';
	    }
	    if (col == 0 && row == 2) {
	        button = '7';
	    }
	    if (col == 0 && row == 3) {
	        button = '*';
	    }
	    if (col == 1 && row == 0) {
	                button = '2';
	    }
	    if (col == 1 && row == 1) {
	                button = '5';
	    }
	    if (col == 1 && row == 2) {
	                button = '8';
	    }
	    if (col == 1 && row == 2) {
	                button = '0';
	    }
	    if (col == 2 && row == 0) {
	                button = '3';
	    }
	    if (col == 2 && row == 1) {
	                button = '6';
	    }
	    if (col == 2 && row == 2) {
	                button = '9';
	    }
	    if (col == 2 && row == 3) {
	                button = '#';
	    }
	    lcd_char(button);*/
	    }
}
	    //NAND = !(BOOLEAN && BOOLEAN)


