/*
 * uart.h
 *
 *  Created on: May 9, 2018
 *      Author: garthleung
 */

#ifndef UART_H_
#define UART_H_


void UART0_init(void);
void sendchar(char word);
void sendline(char line[]);
void sendnewline();
void clear_screen();
void main_menu();
void cursor_right(int space);
void cursor_left(int space);
void cursor_down(int space);
void cursor_corner(void);
void update_DC(double dc);
void update_AC(double ac);
void update_DCO(double dco);
void update_VPP(double vpp);
void update_FREQ(double freq);
void update_DCBAR(double dc);
void update_RMSBAR(double rms);
void clearline();
void update_wave(int wave);

#endif /* UART_H_ */
