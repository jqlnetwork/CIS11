#include "msp.h"
#include "uart.h"
#include "delay.h"
/**
 * main.c
 */

float a = 1.6234;
float b = 0.5;
void main(void)
{
	WDT_A->CTL = WDT_A_CTL_PW | WDT_A_CTL_HOLD;		// stop watchdog timer
    UART0_init();
    main_menu();
    while(1){
        update_DC(a);
        update_AC(b);
        update_DCO(1.64);
        update_VPP(1.65);
        update_FREQ(903.3);
        update_DCBAR(0.7);
        update_RMSBAR(b);
        update_wave(3);
        b += 0.01;
        delay_ms(1000,3);
       }
}
