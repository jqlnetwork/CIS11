/*
 * delay.c
 *
 *  Created on: Apr 6, 2018
 *      Author: garthleung
 */
#include "delay.h"

#define FREQ_1_5_MHz 1
#define FREQ_3_MHz 3
#define FREQ_6_MHz 6
#define FREQ_12_MHz 12
#define FREQ_24_MHz 24
#define FREQ_48_MHz 48

int delay_ms(sec,freq){ //off by a factor of 10
    int i;
    if(freq ==1)
        for(i=150* sec ; i > 0 ; i--);
    else
        for(i = 100 * freq * sec ; i > 0 ; i--);
}
int delay_us(sec,freq){
     float scale;
     int i;
     scale = .0966;
            for( i = freq *scale *sec  ; i > 0 ; i--);
}
