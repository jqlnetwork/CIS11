/*
 * uart.c
 *
 *  Created on: May 9, 2018
 *      Author: garthleung
 */

#include "msp.h"
#include "uart.h"
#include <stdio.h>
#include "string.h"

void sendchar(char word){
    while(!(EUSCI_A0 -> IFG & 0x02));
    EUSCI_A0 -> TXBUF = word;
}

void UART0_init(void)
{
    EUSCI_A0->CTLW0 |= 1;       //put in reset mode for config
    EUSCI_A0->MCTLW = 0;        // disable oversampling
    EUSCI_A0->CTLW0 = 0x0081;   // 1 stop bit, no parity, SMCLK, 8-bit data
    EUSCI_A0->BRW = 26;         // 3,000,000 / 115200 = 26    //was 26 now its 78 to try 9600

    P1->SEL0 |= 0x0C;           // P1.3, P1.2 for UART
    P1->SEL1 &= ~0x0C;
    EUSCI_A0->CTLW0 &= ~1;      // take UART out of reset mode
}

void sendline(char line[]){
    int i = 0;
    for (i = 0 ; i < strlen(line) ; i++){
        sendchar(line[i]);
    }
}
void sendnewline(){
    sendchar('\n');
    sendchar(13);
}

void clear_screen(){
    sendchar(27);               //Ascii code for Esc
    sendchar(91);
    sendchar(50);
    sendchar(74);
}

void clearline(){
    sendchar(27);
    sendchar(91);
    sendchar(50);
    sendchar(75);
}

void main_menu(){
    sendline("_______________________________________________");
    sendnewline();
    sendline("DC Measurements");
    sendnewline();
    sendnewline();
    sendline("DC Voltage: ");
    sendnewline();
    sendnewline();
    sendline("DC Bar Graph:                     * = 0.1V");
    sendnewline();
    sendline("|         |         |         |   ");
    sendnewline();
    sendline("0         1         2         3   ");
    sendnewline();
    sendline("_______________________________________________");
    sendnewline();
    sendline("AC Measurements");
    sendnewline();
    sendnewline();
    sendline("AC Voltage: ");
    sendnewline();
    sendnewline();
    sendline("DC Offset: ");
    sendnewline();
    sendnewline();
    sendline("Vpp: ");
    sendnewline();
    sendnewline();
    sendline("Frequency: ");
    sendnewline();
    sendnewline();
    sendline("True RMS Bar Graph:               * = 0.1V");
    sendnewline();
    sendline("|         |         |         |   ");
    sendnewline();
    sendline("0         1         2         3   ");
    sendnewline();
    sendline("_______________________________________________");
    sendnewline();
    sendline("Waveform: ");
    sendnewline();
    sendline("_______________________________________________");
    sendnewline();
}

void cursor_right(int space){
    sendchar(27);               //Ascii code for Esc
    sendchar(91);               //Ascii code for [
    sendchar(48+space);         //Ascii code for spaces right (to navigate)
    sendchar(67);               //Ascii code for C (turn right))
}
void cursor_left(int space){
    sendchar(27);               //Ascii code for Esc
    sendchar(91);               //Ascii code for [
    sendchar(48+space);         //Ascii code for spaces right (to navigate)
    sendchar(68);               //Ascii code for C (turn left))
}

void cursor_down(int space){
    sendchar(27);               //Ascii code for Esc
    sendchar(91);               //Ascii code for [
    sendchar(48+space);         //Ascii code for spaces right (to navigate)
    sendchar(66);               //Ascii code for B (turn down))
}
void cursor_corner(void){
    sendchar(27);               //Ascii code for Esc
    sendchar(91);               //Ascii code for [
    sendchar(72);               //Ascii code for H
}

void update_DC(double dc){
    float value;
    char data;

    cursor_corner();
    cursor_down(3);
    cursor_right(9);
    cursor_right(2);

    value = dc;
    if (value > 9.9){
        value = 9.9;
    }
    data = (int)value + '0';                //change this to number value on ascii, 1's place
    sendchar(data);
    sendchar('.');
    value = (value - (int)value) * 10;      //changing to 0.1's place
    data = (int)value + '0';
    sendchar(data);
    value = (value - (int)value) * 10;      //changing to 0.01's place
    data = (int)value + '0';
    sendchar(data);
}

void update_AC(double ac){
    float value;
    char data;

    cursor_corner();
    cursor_down(8);
    cursor_down(3);
    cursor_right(9);
    cursor_right(2);

    value = ac;
    if (value > 9.9){
        value = 9.9;
    }
    data = (int)value + '0';                //change this to number value on ascii, 1's place
    sendchar(data);
    sendchar('.');
    value = (value - (int)value) * 10;      //changing to 0.1's place
    data = (int)value + '0';
    sendchar(data);
    value = (value - (int)value) * 10;      //changing to 0.01's place
    data = (int)value + '0';
    sendchar(data);
}

void update_DCO(double dco){
    float value;
    char data;

    cursor_corner();
    cursor_down(9);
    cursor_down(4);
    cursor_right(9);
    cursor_right(1);

    value = dco;
    if (value > 9.9){
        value = 9.9;
    }
    data = (int)value + '0';                //change this to number value on ascii, 1's place
    sendchar(data);
    sendchar('.');
    value = (value - (int)value) * 10;      //changing to 0.1's place
    data = (int)value + '0';
    sendchar(data);
    value = (value - (int)value) * 10;      //changing to 0.01's place
    data = (int)value + '0';
    sendchar(data);
}
void update_VPP(double vpp){
    float value;
    char data;

    cursor_corner();
    cursor_down(9);
    cursor_down(6);
    cursor_right(4);

    value = vpp;
    if (value > 9.9){
        value = 9.9;
    }
    data = (int)value + '0';                //change this to number value on ascii, 1's place
    sendchar(data);
    sendchar('.');
    value = (value - (int)value) * 10;      //changing to 0.1's place
    data = (int)value + '0';
    sendchar(data);
    value = (value - (int)value) * 10;      //changing to 0.01's place
    data = (int)value + '0';
    sendchar(data);
}
void update_FREQ(double freq){
    float value;
    char data;

    cursor_corner();
    cursor_down(9);
    cursor_down(8);
    cursor_right(9);
    cursor_right(1);

    value = freq;
    sendchar( '0' + (int)value/1000);
    value -= ((int)(value/1000) * 1000); //double temp1
    sendchar( '0' + (int)value/100);
    //double temp = ((int)(value/100) * 100); //double temp
    value -= ((int)(value/100) * 100);
    sendchar( '0' + (int)value/10);
    value -= ((int)(value/10) * 10);
    sendchar( '0' + (int)value);               //change this to number value on ascii, 1's place
    sendchar('.');
    value = (value - (int)value) * 10;         //0.1's place
    sendchar( '0' + (int)value);
    value = (value - (int)value) * 10;
    sendchar( '0' + (int)value);
}

void update_DCBAR(double dc){
    cursor_corner();
    cursor_down(6);
    //cursor_right(1);
    clearline();
    sendline("|         |         |         |   ");
    cursor_left(9);
    cursor_left(9);
    cursor_left(9);
    cursor_left(6);
    int width = (dc / 0.10);
    int i = 0;
    for (i ; i < (width+1) ; i++){
        sendchar('*');
    }
}
void update_RMSBAR(double rms){
    cursor_corner();
    cursor_down(9);
    cursor_down(9);
    cursor_down(2);
   // cursor_right(1);
    clearline();
    sendline("|         |         |         |   ");
    cursor_left(9);
    cursor_left(9);
    cursor_left(9);
    cursor_left(6);
    int width = (rms / 0.10);
    int i = 0;
    for (i ; i < (width+1) ; i++){
        sendchar('*');
    }
}

void update_wave(int wave){
    cursor_corner();
    cursor_down(9);
    cursor_down(9);
    cursor_down(5);
    cursor_right(9);
    if (wave == 1){
        sendline("Sine");
    }
    if (wave == 2){
        sendline("Triangular");
    }
    if (wave == 3){
        sendline("Square");
    }
}

