#include "msp.h"
#include "set_DCO.h"
//find out what freq you start with by diving 1/period. then take your DCO and divide it by that freq
/** thats how much CCR0 you have, divide it by how many cycles (2 or 4?) then thats how many cycles of CCR0 you
 * need to do. if you make CCR0 a certain value, divide that cycle count by the CCR0 certain value, thats how many times you repeat.
 * main.c
 */
#define FREQ_1_5_MHz 1
#define FREQ_3_MHz 3
#define FREQ_6_MHz 6
#define FREQ_12_MHz 12
#define FREQ_24_MHz 24
#define FREQ_48_MHz 48
int i = 0;
void main(void)
{
	WDT_A->CTL = WDT_A_CTL_PW | WDT_A_CTL_HOLD;		// stop watchdog timer
    set_DCO(1);
	P1 -> DIR |= BIT0;
	P1 -> OUT &= ~BIT0;         //P1.0 as output and is low
	P2 -> DIR |= BIT0;
	P2 -> OUT &= ~BIT0;         //P2.0 as output and is low
	P4 -> DIR |= BIT3;
	P4 -> SEL1 &= ~BIT3;
	P4 -> SEL0 |= BIT3;
    TIMER_A0 -> CCTL[0] &= ~TIMER_A_CCTLN_CCIFG;        // Clear flag
	TIMER_A0 -> CCTL[0] |= TIMER_A_CCTLN_CCIE;          // enable interrupts
	TIMER_A0 -> CCR[0] = 32768;
	TIMER_A0 -> CTL = TIMER_A_CTL_TASSEL_1 | TIMER_A_CTL_MC_1;
	__enable_irq();
	NVIC -> ISER[0] = 1 << ((TA0_0_IRQn) & 31);
	while(1);
}

void TA0_0_IRQHandler(void){                    //CCR[0] ISR for 25kHz (50% Duty Cycle)
    TIMER_A0 -> CCTL[0] &= ~TIMER_A_CCTLN_CCIFG;
    i = i+1;
    if (i > 458 ){
        P1 -> OUT ^=  BIT0;
        i = 0;
    }
}
       //if (P1 -> OUT &= BIT0) {
       //     P1 -> OUT &= ~BIT0;
       //     TIMER_A0 -> CCR[0] += ;
       // }
       // else {
       //     P1 -> OUT |= BIT0;
       //     TIMER_A0 -> CCR[0] += 32768;
       // }
       // i--;

