/*
 * set_DCO.h
 *
 *  Created on: Apr 6, 2018
 *      Author: garthleung
 */

#ifndef SET_DCO_H_
#define SET_DCO_H_
#define FREQ_1_5_MHz 1
#define FREQ_3_MHz 3
#define FREQ_6_MHz 6
#define FREQ_12_MHz 12
#define FREQ_24_MHz 24
#define FREQ_48_MHz 48


int set_DCO(int freq);


#endif /* SET_DCO_H_ */
