/*
 * set_DCO.c
 *
 *  Created on: Apr 6, 2018
 *      Author: garthleung
 */
#include "msp.h"
#include "set_DCO.h"
//define clock frequencies
#define FREQ_1_5_MHz 1
#define FREQ_3_MHz 3
#define FREQ_6_MHz 6
#define FREQ_12_MHz 12
#define FREQ_24_MHz 24
#define FREQ_48_MHz 48
int set_DCO(freq){
    // change DC0 from default of 3MHz to 12MHz.
    CS->KEY = CS_KEY_VAL; // unlock CS registers
    CS->CTL0 = 0; // clear register CTL0

    if (freq == 1){
           CS->CTL0 = CS_CTL0_DCORSEL_0; // set DCO = 1.5MHz
           CS->CTL1 = CS_CTL1_SELA_2 | CS_CTL1_SELS_3 | CS_CTL1_SELM_3;
            }
    if (freq == 3){
           CS->CTL0 = CS_CTL0_DCORSEL_1; // set DCO = 3MHz
           CS->CTL1 = CS_CTL1_SELA_2 | CS_CTL1_SELS_3 | CS_CTL1_SELM_3;
            }
    if (freq == 6){
           CS->CTL0 = CS_CTL0_DCORSEL_2; // set DCO = 6MHz
           CS->CTL1 = CS_CTL1_SELA_2 | CS_CTL1_SELS_3 | CS_CTL1_SELM_3;
            }
    if (freq == 12){
           CS->CTL0 = CS_CTL0_DCORSEL_3; // set DCO = 12 MHz
           CS->CTL1 = CS_CTL1_SELA_2 | CS_CTL1_SELS_3 | CS_CTL1_SELM_3;
            }
    if (freq == 24){
           CS->CTL0 = CS_CTL0_DCORSEL_4; // set DCO = 24 MHz
           CS->CTL1 = CS_CTL1_SELA_2 | CS_CTL1_SELS_3 | CS_CTL1_SELM_3;
            }
    if (freq == 48){
            while ((PCM->CTL1 & PCM_CTL1_PMR_BUSY));
            PCM->CTL0 = PCM_CTL0_KEY_VAL | PCM_CTL0_AMR_1;
            while ((PCM->CTL1 & PCM_CTL1_PMR_BUSY));
            /* Configure Flash wait-state to 1 for both banks 0 & 1 */
            FLCTL->BANK0_RDCTL = (FLCTL->BANK0_RDCTL & ~(FLCTL_BANK0_RDCTL_WAIT_MASK)) | FLCTL_BANK0_RDCTL_WAIT_1;
            FLCTL->BANK1_RDCTL = (FLCTL->BANK0_RDCTL & ~(FLCTL_BANK1_RDCTL_WAIT_MASK)) | FLCTL_BANK1_RDCTL_WAIT_1;
            CS->KEY = CS_KEY_VAL ; // Unlock CS module for register access
            CS->CTL0 = 0; // Reset tuning parameters
            CS->CTL0 = CS_CTL0_DCORSEL_5; // Set DCO to 48MHz
            CS->CTL1 = CS->CTL1 & ~(CS_CTL1_SELM_MASK | CS_CTL1_DIVM_MASK) | CS_CTL1_SELM_3;
            }
    CS->KEY = 0; // lock the CS registers
}


