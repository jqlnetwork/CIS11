#include "msp.h"
#include "uart.h"

void transmitChar(char c)
{
    while(!(EUSCI_A0->IFG & 0x02)) { }  // wait for transmit buffer empty
    EUSCI_A0->TXBUF = c;
}

void UART0_init(void)
{
    EUSCI_A0->CTLW0 |= 1;       //put in reset mode for config
    EUSCI_A0->MCTLW = 0;        // disable oversampling
    EUSCI_A0->CTLW0 = 0x0081;   // 1 stop bit, no parity, SMCLK, 8-bit data
    EUSCI_A0->BRW = 26;         // 3,000,000 / 115200 = 26

    P1->SEL0 |= 0x0C;           // P1.3, P1.2 for UART
    P1->SEL1 &= ~0x0C;
    EUSCI_A0->CTLW0 &= ~1;      // take UART out of reset mode

}

/* delay milliseconds when system clock is at 3 MHz */
void delayMs(int n)
{
    int i, j;

    for (j = 0; j < n; j++)
        for (i = 750; i > 0; i--);      // Delay */
}

/*clear the terminal line*/
void clr_term_line(void)
{
    transmitChar(' ');
    transmitChar(' ');
    transmitChar(' ');
    transmitChar(' ');
    transmitChar(' ');
    transmitChar(' ');
    transmitChar(' ');
    transmitChar(13);

}




