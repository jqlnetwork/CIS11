#include "msp.h"
#include <stdio.h>
#include "uart.h"
#include "adc.h"

static unsigned int iflag = 0;

int main(void)
{


    /* Configure P2.2-P2.0 as output for tri-color LEDs */
    P2->SEL0 &= ~7;
    P2->SEL1 &= ~7;
    P2->DIR |= 7;

    /*uart interrupt init*/
    UART0_init();
    adc_init();

    /*clear line in terminal*/
    clr_term_line();


    start_conversion();  // start a conversion

    while (1)
    {
        if(conversion_complete())
        {
            transmitADC_result();

            clr_conversion_flag();
            start_conversion();
        }
    }
}

