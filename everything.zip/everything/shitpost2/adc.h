///*
// * adc.h
// *
// *  Created on: May 10, 2018
// *      Author: garthleung
// */
//
//#ifndef ADC_H_
//#define ADC_H_
//
//
//
//
//
//#endif /* ADC_H_ */

#ifndef ADC_H_
#define ADC_H_

#define ONE_V_ADC   4970

void adc_init(void);
int conversion_complete(void);
void clr_conversion_flag(void);
void start_conversion(void);
void transmitADC_result(void);

#endif /* ADC_H_ */
