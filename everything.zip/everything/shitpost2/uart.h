///*
// * uart.h
// *
// *  Created on: May 10, 2018
// *      Author: garthleung
// */
//
//#ifndef UART_H_
//#define UART_H_
//
//
//
//
//
//#endif /* UART_H_ */

#ifndef UART_H
#define UART_H

void UART0_init(void);
void delayMs(int n);
void transmitChar(char c);
void clr_term_line(void);

#endif
