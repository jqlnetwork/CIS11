#include "msp.h"
#include "adc.h"
#include "uart.h"

static unsigned int iflag = 0;
static unsigned int ADC_val = 0;

int conversion_complete()
{
    return iflag;
}

void clr_conversion_flag()
{
    iflag = 0;
}

void start_conversion()
{
    ADC14->CTL0 |= ADC14_CTL0_SC;   // start a conversion
}


void transmitADC_result()
{
    float temp;
    char c;

    P2->OUT = ADC_val >> 8;     // display bits 10-8 on tri-color LEDs

    transmitChar(13);

    /*determine the voltage from the 1V unit*/
    temp = ADC_val;
    temp /= ONE_V_ADC;              //determine value for the 1s position
    c = (int)temp + '0';
    transmitChar(c);
    transmitChar('.');

    temp = (temp - (int)temp) * 10; //determine value for the 0.1s position
    c = (int)temp + '0';
    transmitChar(c);

    temp = (temp - (int)temp) * 10; //determine value for the 0.01s position
    c = (int)temp + '0';
    transmitChar(c);

    delayMs(100);   //delay to decrease jitter from printing to terminal

}

void adc_init(void)
{
    ADC14->CTL0 =  ADC14_CTL0_ON ;              //power on and disabled during configuration
    ADC14 -> CTL0 &= ~ADC14_CTL0_ENC;
    // S/H pulse mode, sysclk, 32 sample clocks, software trigger  (0x04080300)
    //ADC14->CTL0 |= (ADC14_CTL0_SHP | ADC14_CTL0_SSEL__SYSCLK | ADC14_CTL0_SHT0__128 );
    ADC14 -> CTL0 |= (ADC14_CTL0_SHT0_3 | ADC14_CTL0_SHP | ADC14_CTL0_SSEL_1);
    ADC14->CTL1 =  ADC14_CTL1_RES__14BIT;       // 12-bit resolution

    ADC14->MCTL[5] = 15;                        // memreg5, A15 input, single-ended, Vref=AVCC
    P6->SEL1 |= 0x01;                           // Configure P6.0 for A15
    P6->SEL0 |= 0x01;
    ADC14->CTL1 |= 0x00050000;                  // convert for memreg 5

    /*configure ADC14 interrupts*/
    ADC14->IER0 = ADC14_IER0_IE5;       //enable interrupts for memreg5 channels
    NVIC->ISER[0] = 1 << ((ADC14_IRQn) & 31);
    __enable_irq();                     //enable global IRQs

    ADC14->CTL0 |= ADC14_CTL0_ENC;      // enable ADC after configuration

}

void ADC14_IRQHandler(void)
{
    ADC_val = ADC14->MEM[5];

    iflag = 1;
}
