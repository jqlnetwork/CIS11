#include "msp.h"
#include "set_DCO.h"
#include "drive_DAC.h"

/* 3 PIN SPI Mode because CS is low while data is transferred so UCB0 will be configured as SPI
 * and connected to MCP4921
 */
int peak = 0;
void main(void){
    WDT_A->CTL = WDT_A_CTL_PW | WDT_A_CTL_HOLD;     // stop watchdog timer
    set_DCO(3);

    EUSCI_B0 -> CTLW0 = 0x0001; //So UCB0 isnt changed during this
    EUSCI_B0 -> CTLW0 = 0xA9C1; //Rising edge, active high clock, MSB, 8 bit data, Master mode, 3-pin SPI, Synchronomous mode, SMCLK, Enabled USCI logic held
    EUSCI_B0 -> BRW = 0x0001;        //3 MHz
    EUSCI_B0 -> CTLW0 &= ~0x0001; //UCB0 is enabled now

    P1 -> SEL0 |= BIT5 | BIT6;    //This makes P1.5 and P1.6 become initiated as CLK and MOSI for UCB0
    P1 -> SEL1 &= ~(BIT5 | BIT6); //0x60;
    P2 -> DIR |= BIT3;
    P2 -> OUT |= BIT3;
    TIMER_A0 -> CCTL[0] &= ~TIMER_A_CCTLN_CCIFG;
 //   TIMER_A0 -> CCTL[1] &= ~TIMER_A_CCTLN_CCIFG;
    TIMER_A0 -> CCTL[0] |= TIMER_A_CCTLN_CCIE;
 //   TIMER_A0 -> CCTL[1] |= TIMER_A_CCTLN_CCIE;
//    float freq = 50;        // just change these, freq = 50hz             //SQUARE WAVE
//    float duty = 50;        // duty cycle = 50%
//    float duty_p = (duty/100.0);
//    float off_cycles = ((3000000/freq) * duty_p);       //using 3 MHz
//    TIMER_A0 -> CCR[0] = (3000000/freq);
//    TIMER_A0 -> CCR[1] = off_cycles;
    TIMER_A0 -> CCR[0] = 500;          //as CCR0 ^, FREQ v ,                                //TRIANGLE WAVE



    TIMER_A0 -> CTL = TIMER_A_CTL_TASSEL_2  |  TIMER_A_CTL_MC_1  |  TIMER_A_CTL_ID_0;
    __enable_irq();
    NVIC -> ISER[0] = 1 << ((TA0_0_IRQn) & 31);
    //NVIC -> ISER[0] = 1 << ((TA0_N_IRQn) & 31);

    while(1);
}

void TA0_0_IRQHandler(void){
//   TIMER_A0 -> CCTL[0] &= ~TIMER_A_CCTLN_CCIFG;
//   drive_dac(0x962); //for Square Wave
    TIMER_A0 -> CCTL[0] &= ~TIMER_A_CCTLN_CCIFG;
    static int data = 0;
    int step = 0x007C;
    static int i=0;
    if (peak == 0){
        drive_dac(data);
        data = data + step;
        i++;
        if(i == 20){
            i = 0;
            peak = 1;
        }
    }
    if (peak == 1){
        drive_dac(data);
        data = data - step;
        i++;
        if(i == 20){
            i = 0;
            peak = 0;
        }
    }
}

//void TA0_N_IRQHandler(void){
//    if (TIMER_A0 -> CCTL[1] & TIMER_A_CCTLN_CCIFG){
//    TIMER_A0 -> CCTL[1] &= ~TIMER_A_CCTLN_CCIFG;
//    drive_dac(0x000); //for Square Wave
//    }
//}

