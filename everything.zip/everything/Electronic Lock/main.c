#include "msp.h"


/**
 * main.c
 */
void main(void)
{
	WDT_A->CTL = WDT_A_CTL_PW | WDT_A_CTL_HOLD;		// stop watchdog timer
}


void home_screen(void){
    lcd_init();
    delay_ms(50,3);
    lcd_setup();
    lcd_command(entry_mode_on); //Initialized the LCD
    char word[] = "LOCKED";
    lcd_string(word);
    lcd_command(setDDRAM_bottom);
    char word1[] = "ENTER KEY ";
    lcd_string(word1);
}
