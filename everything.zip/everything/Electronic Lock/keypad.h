/*
 * keypad.h
 *
 *  Created on: Apr 18, 2018
 *      Author: garthleung
 */

#ifndef KEYPAD_H_
#define KEYPAD_H_

#define row1 BIT5
#define row2 BIT7
#define row3 BIT6
#define row4 BIT4
#define col1 BIT1
#define col2 BIT0
#define col3 BIT2

void keypad_map(void);
void keypad_wrc(void);
void keypad_wr(void);



#endif /* KEYPAD_H_ */

