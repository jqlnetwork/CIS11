/*
 * keypad.c
 *
 *  Created on: Apr 18, 2018
 *      Author: garthleung
 */
#include "msp.h"
#include "delay.h"
#include "LCD.h"
#include "string.h"
#include "keypad.h"

#define row1 BIT5
#define row2 BIT7
#define row3 BIT6
#define row4 BIT4
#define col1 BIT1
#define col2 BIT0
#define col3 BIT2

//function writes the button pressed to LCD and clears
void keypad_wrc(void)
{

    //define column read
    int read = P5 -> IN ;
    int col = (read & 0x07);

    WDT_A->CTL = WDT_A_CTL_PW | WDT_A_CTL_HOLD; //stop watchdog timer





    P5->DIR |= (row1 | row2 | row3 | row4); //rows as outputs
    P5->OUT |= (row1 | row2 | row3 | row4); //drive rows high
    P5->DIR &= ~(col1 | col2 | col3);       //set columns as inputs
    P5->REN |= (col1 | col2 | col3);        //enable resistors
    P5->OUT |= (col1 | col2 | col3);        //make pullup

    LCD_init();
    LCD_startup();

    while(1){

       // check first row
        P5->OUT &= ~(row1);

       // read columns
        read = P5 -> IN ;
        col = (read & 0x07);


           //check each column
        if (col == 0x05){
           Clear_LCD();
           LCD_write_char('1');
        }
  if (col == 0x06){
            Clear_LCD();
            LCD_write_char('2');
           }
          if (col == 0x03){
            Clear_LCD();
            LCD_write_char('3');
       }

          P5->OUT |= row1;    // reset first row
       P5->OUT &= ~(row2); // check second row

         // read columns again
       read = P5 -> IN ;
       col = (read & 0x07);




   if (col == 0x05){
            Clear_LCD();
            LCD_write_char('4');
        }
        if (col == 0x06){
            Clear_LCD();
            LCD_write_char('5');
            }
        if (col == 0x03){
            Clear_LCD();
            LCD_write_char('6');
            }


        P5->OUT |= row2; // reset second row
        P5->OUT &= ~(row3); //drive and check third row

      // read columns
        read = P5 -> IN ;
        col = (read & 0x07);

       // check each column
        if (col == 0x05){
            Clear_LCD();
            LCD_write_char('7');
        }
        if (col == 0x06){
            Clear_LCD();
            LCD_write_char('8');
        }
        if (col == 0x03){
            Clear_LCD();
            LCD_write_char('9');
        }

        P5->OUT |= row3;
        P5->OUT &= ~(row4);
        read = P5 -> IN ;
        col = (read & 0x07);




        if (col == 0x05){
            Clear_LCD();
           LCD_write_char('*');
        }
        if (col == 0x06){
           Clear_LCD();
           LCD_write_char('0');
        }
        if (col == 0x03){
           Clear_LCD();
           LCD_write_char('#');
        }

        P5->OUT |= row4; // reset 4th row
                delay_ms(90,3);  //90ms is about length of press
    }
}

//function writes the locations of the button pressed to LCD
//function was used mainly for testing
void keypad_map(void){
    int read = P5 -> IN ;
    int col = (read & 0x07);

    WDT_A->CTL = WDT_A_CTL_PW | WDT_A_CTL_HOLD; // stop watchdog timer




    P5->DIR |= (row1 | row2 | row3 | row4);  // rows as outputs
    P5->OUT |= (row1 | row2 | row3 | row4);  // drive rows high
    P5->DIR &= ~(col1 | col2 | col3);        // set columns as inputs
    P5->REN |= (col1 | col2 | col3);         // enable resistors
    P5->OUT |= (col1 | col2 | col3);         // make pullup

    LCD_init();
    LCD_startup();






    while(1){

        P5->OUT &= ~(row1);  // check first row

       // read columns
        read = P5 -> IN ;
        col = (read & 0x07);

        // check each column
        if (col == 0x05){
            Clear_LCD();
            char row1col1[] = "row1col1";
            LCD_string(row1col1);
           }
        if (col == 0x06){
            Clear_LCD();
            char word[] = "row1col2";
            LCD_string(word);
        }
        if (col == 0x03){
            Clear_LCD();
            char word[] = "row1col3";
           LCD_string(word);
        }

       P5->OUT |= row1;  // reset 1st row
           P5->OUT &= ~(row2); // check second row

           // read in columns
        read = P5 -> IN ;
        col = (read & 0x07);

       // check each column
        if (col == 0x05){
            Clear_LCD();
            char row1col1[] = "row2col1";
            LCD_string(row1col1);
        }
        if (col == 0x06){
            Clear_LCD();
            char word[] = "row2col2";
            LCD_string(word);
            }
        if (col == 0x03){
            Clear_LCD();
            char word[] = "row2col3";
            LCD_string(word);
        }


        P5->OUT |= row2; // reset row
        P5->OUT &= ~(row3); // check third row

        // read in columns
        read = P5 -> IN ;
        col = (read & 0x07);

      // check each column
        if (col == 0x05){
         Clear_LCD();
            char row1col1[] = "row3col1";
            LCD_string(row1col1);
        }
        if (col == 0x06){
            Clear_LCD();
            char word[] = "row3col2";
            LCD_string(word);
        }
        if (col == 0x03){
            Clear_LCD();
            char word[] = "row3col3";
            LCD_string(word);
        }


        P5->OUT |= row3; // reset row
        P5->OUT &= ~(row4); // check 4th row

   // read in columns
        read = P5 -> IN ;
        col = (read & 0x07);





        if (col == 0x05){
            Clear_LCD();
            char row1col1[] = "row4col1";
            LCD_string(row1col1);
        }
        if (col == 0x06){
            Clear_LCD();
            char word[] = "row4col2";
            LCD_string(word);
        }
        if (col == 0x03){
            Clear_LCD();
            char word[] = "row4col3";
            LCD_string(word);
        }

        P5->OUT |= row4;
        delay_ms(90,3);
    }

}


//function operates the same as keypad_wrc but the LCD is not cleared
void keypad_wr(void)
{

    int read = P5 -> IN ;
    int col = (read & 0x07);

    WDT_A->CTL = WDT_A_CTL_PW | WDT_A_CTL_HOLD; // stop watchdog timer

    P5->DIR |= (row1 | row2 | row3 | row4);
    P5->OUT |= (row1 | row2 | row3 | row4);
    P5->DIR &= ~(col1 | col2 | col3);
    P5->REN |= (col1 | col2 | col3);
    P5->OUT |= (col1 | col2 | col3);

    LCD_init();
    LCD_startup();



    while(1){

        P5->OUT &= ~(row1);

        read = P5 -> IN ;
        col = (read & 0x07);



          if (col == 0x05){
            LCD_write_char('1');
           }
          if (col == 0x06){
            LCD_write_char('2');
        }
          if (col == 0x03){
            LCD_write_char('3');
        }

      P5->OUT |= row1;
          P5->OUT &= ~(row2);

          read = P5 -> IN ;
          col = (read & 0x07);


        if (col == 0x05){
            LCD_write_char('4');
        }
        if (col == 0x06){
            LCD_write_char('5');
        }
        if (col == 0x03){
            LCD_write_char('6');
        }

        P5->OUT |= row2;
        P5->OUT &= ~(row3);

        read = P5 -> IN ;
        col = (read & 0x07);


        if (col == 0x05){
              LCD_write_char('7');
        }
        if (col == 0x06){
             LCD_write_char('8');
        }
        if (col == 0x03){
  LCD_write_char('9');
        }

        P5->OUT |= row3;
        P5->OUT &= ~(row4);

        read = P5 -> IN ;
        col = (read & 0x07);


        if (col == 0x05){
  LCD_write_char('*');
        }
        if (col == 0x06){
             LCD_write_char('0');
        }
        if (col == 0x03){
             LCD_write_char('#');
        }

        P5->OUT |= row4;
        delay_ms(90,3);
    }
}




