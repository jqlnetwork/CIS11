#include "msp.h"
#include "delay.h"
#include "set_DCO.h"
#include "string.h"

//don't know if i need to do this again
#define FREQ_1_5_MHz 1
#define FREQ_3_MHz 3
#define FREQ_6_MHz 6
#define FREQ_12_MHz 12
#define FREQ_24_MHz 24
#define FREQ_48_MHz 48

#define RS BIT5
#define RW BIT6
#define EN BIT7

#define clear_disp 0x01
#define function_set 0x28 //nibble mode function set
#define display_on 0x0F     //refer to table to get display_off
#define entry_mode_on 0x06  //apparently 0x07 makes it disappear
#define setDDRAM_bottom 0xC0
#define setDDRAM_top 0x80
#define setDDRAM_middletop 0x85
int main(void) {
    lcd_init();
    delay_ms(50,3);
    lcd_setup();
    lcd_command(entry_mode_on);
    char word[] = "LOCKED";
    lcd_string(word);
    lcd_command(setDDRAM_bottom);
    char word1[] = "ENTER KEY";
    lcd_string(word1);
    for( ; ; );
}
